-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 14, 2016 at 11:57 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE IF NOT EXISTS `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `author` text NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `name`, `author`, `description`, `image`) VALUES
(1, 'book1', 'author1', 'This is a short description for book1!', 'img-book/accounting.jpg'),
(2, 'book2', 'author2', 'This is a short description for book2!', 'img-book/nick_1x.jpg'),
(3, 'book3', 'author3', 'This is a short description for book3', 'img-book/quartz_1x.jpg'),
(4, 'book4', 'author4', 'This is a short description for book4!', 'img-book/sweater.png');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `uid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `book` text NOT NULL,
  `image` text NOT NULL,
  `video` text NOT NULL,
  `audio` text NOT NULL,
  `pdf` text NOT NULL,
  UNIQUE KEY `cid` (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`uid`, `cid`, `book`, `image`, `video`, `audio`, `pdf`) VALUES
(1, 2, 'book1', 'images/1.JPG', '/videos/movie (1).mp4', '/audios/CD1 (1).mp3', '/pdfs/pdf (1).pdf'),
(1, 3, 'book2', 'images/2.JPG', '/videos/movie (2).mp4', '/audios/CD1 (2).mp3', '/pdfs/pdf (2).pdf'),
(1, 4, 'book3', 'images/3.JPG', '/videos/movie (3).mp4', '/audios/CD1 (3).mp3', '/pdfs/pdf (3).pdf'),
(1, 5, 'book4', 'images/4.JPG', '/videos/movie (4).mp4', '/audios/CD1 (4).mp3', '/pdfs/pdf (4).pdf');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `uid` int(11) NOT NULL,
  `student_name` text NOT NULL,
  `password` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`uid`, `student_name`, `password`) VALUES
(1, 'mehrshad', '1'),
(2, 'ali', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `name` text NOT NULL,
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user_email` text NOT NULL,
  `user_password` text NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `uid`, `user_email`, `user_password`) VALUES
('', 1, 'admin@gmail.com', 'admin'),
('', 2, '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
