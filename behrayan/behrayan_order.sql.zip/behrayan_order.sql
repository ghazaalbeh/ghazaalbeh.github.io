-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 14, 2016 at 04:25 PM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `behrayan_order`
--

-- --------------------------------------------------------

--
-- Table structure for table `apporder`
--

CREATE TABLE IF NOT EXISTS `apporder` (
  `AppPacketChoice` text COLLATE utf8_persian_ci NOT NULL,
  `AppStoreName` text COLLATE utf8_persian_ci NOT NULL,
  `AppWebAddress` text COLLATE utf8_persian_ci NOT NULL,
  `AppName` text CHARACTER SET ucs2 COLLATE ucs2_persian_ci NOT NULL,
  `AppEmail` text COLLATE utf8_persian_ci NOT NULL,
  `AppTel` text COLLATE utf8_persian_ci NOT NULL,
  `AppAddress` text COLLATE utf8_persian_ci NOT NULL,
  `AppOthers` text COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `apporder`
--

INSERT INTO `apporder` (`AppPacketChoice`, `AppStoreName`, `AppWebAddress`, `AppName`, `AppEmail`, `AppTel`, `AppAddress`, `AppOthers`) VALUES
('advance', 'wedwed', 'edwedwed', 'wedqwd', 'wedqwd', 'wedqwd', 'wedwed', 'wedfwed');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `packetChoice` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `storeName` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `products` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `colorChoice` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `firstColor` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `secondColor` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `thirdColor` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `fourthColor` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `fifthColor` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `name` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `tel` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
  `others` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`packetChoice`, `storeName`, `products`, `colorChoice`, `firstColor`, `secondColor`, `thirdColor`, `fourthColor`, `fifthColor`, `name`, `email`, `tel`, `address`, `others`) VALUES
('advance', 'Ù†Ø§Ù… ÙØ±ÙˆØ´Ú¯Ø§Ù‡', 'Ø¬Ù†Ø³ ÛŒØ§ Ø§Ø¬Ù†Ø§Ø³ÛŒ Ú©Ù‡ Ù…ÛŒ Ø®ÙˆØ§Ù‡ÛŒØ¯ Ø¨ÙØ±ÙˆØ´ÛŒØ¯ ', 'color8', 'FA2D56', 'FA32B1', 'FA6E8F', '44FA37', '8EB6FA', 'Ù†Ø§Ù… Ùˆ Ù†Ø§Ù… Ø®Ø§Ù†ÙˆØ§Ø¯Ú¯ÛŒ Ø´Ù…Ø§', 'ghazaal.beh@gmail.com', '423232331233', 'ØªÙ‡Ø±Ø§Ù† Ø®ÛŒØ§Ø¨Ø§Ù† Ù…Ù†ÙˆÙ¾Ú†Ù‡Ø± Ú©ÙˆÚ†Ù‡ 3 ÙˆØ§Ø­Ø¯ 6Ø®ÛŒÙ„ÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒ Ø¯ÙˆÙˆÙˆÙˆØ±', 'Ø¨Ù‚Ù„Ø±Ø´Ø³Ø¨Ø³Ø¨ÛŒØ³Ø¨ÛŒ'),
('advance', 'Ù†Ø§Ù… ÙØ±ÙˆØ´Ú¯Ø§Ù‡2', 'Ø¬Ù†Ø³ ÛŒØ§ Ø§Ø¬Ù†Ø§Ø³ÛŒ Ú©Ù‡ Ù…ÛŒ Ø®ÙˆØ§Ù‡ÛŒØ¯ Ø¨ÙØ±ÙˆØ´ÛŒØ¯2 ', 'color8', 'FA0820', '8CFA9E', 'F52563', 'AAFA0A', 'FA9085', 'Ù†Ø§Ù… Ùˆ Ù†Ø§Ù… Ø®Ø§Ù†ÙˆØ§Ø¯Ú¯ÛŒ Ø´Ù…Ø§', 'ghazaal.beh@gmail.com', '423232331233', 'ØªÙ‡Ø±Ø§Ù† Ø®ÛŒØ§Ø¨Ø§Ù† Ù…Ù†ÙˆÙ¾Ú†Ù‡Ø± Ú©ÙˆÚ†Ù‡ 3 ÙˆØ§Ø­Ø¯ 6Ø®ÛŒÙ„ÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒÛŒ Ø¯ÙˆÙˆÙˆÙˆØ±22222', 'Ø¨Ù‚Ù„Ø±Ø´Ø³Ø¨Ø³Ø¨ÛŒØ³Ø¨ÛŒ'),
('advance', 'Ø«Ù‚Ø¨Ø±Ø«Ù‚Ø¨', 'Ø«Ø´Ù‚Ø¨Ø±Ù„Ø«Ù‚Ù„Ø¨', 'color3', '6BC1FA', 'BBFADB', 'EBFA62', '64FAC8', 'FA78F6', 'Ù‚Ø«Ø¨Ø´Ø«ØµÙ‚Ø¨', 'Ø«ØµÙ‚Ø¨ØµØ«Ø¨', 'ØµØ«Ù‚Ø¨ØµØ«Ø¨', 'ØµØ«Ù‚Ø¨ØµØ«Ø¨', 'ØµØ«Ù‚Ø¨ØµØ«Ø¨ØµØ«Ø¨');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
